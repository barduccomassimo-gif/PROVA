
# Calendario dell'Avvento Digitale - Tedua

Questo progetto contiene un calendario interattivo con 24 caselle, ognuna dedicata a una frase iconica di Tedua, una grafica urban e un QR code che rimanda a una sua canzone su Spotify.

## Come visualizzarlo

Apri il file `index.html` in un browser oppure pubblica il repository tramite GitHub Pages:

1. Vai su **Settings** del repository
2. Scorri fino a **Pages**
3. In "Source" seleziona `main` e la cartella `/ (root)`
4. Salva e accedi al link generato

## Autore
Massimo Barducco (@barduccomassimo-gif)
